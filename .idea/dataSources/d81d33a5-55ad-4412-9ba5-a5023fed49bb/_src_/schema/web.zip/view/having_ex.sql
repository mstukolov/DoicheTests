CREATE VIEW `having_ex` AS
  SELECT
    `web`.`lessons`.`room`        AS `room`,
    count(`web`.`lessons`.`room`) AS `NUM`
  FROM `web`.`lessons`
  GROUP BY `web`.`lessons`.`room`
  HAVING (`NUM` > 1)
  ORDER BY `NUM` DESC